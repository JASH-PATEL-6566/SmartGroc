const { getRecipesFromOpenAI } = require("../services/openaiService");
const { filterValidRecipes } = require("../utils/recipeUtils");

exports.handler = async (event) => {
  try {
    const body =
      typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    const userProducts = body.products || [];

    console.log(userProducts);

    const availableIngredients = userProducts.map(
      (item) => item?.nf_ingredient_statement || item?.name
    );

    const recipes = await getRecipesFromOpenAI(availableIngredients);

    console.log("Recipes: " + recipes);

    const validRecipes = filterValidRecipes(recipes, availableIngredients);

    console.log(validRecipes);

    return {
      statusCode: 200,
      body: JSON.stringify({
        count: validRecipes.length,
        recipes: validRecipes,
      }),
    };
  } catch (err) {
    console.error("Error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal server error",
        details: err.message,
      }),
    };
  }
};
