const { handler } = require('./handlers/recipeHandler');
exports.handler = handler;
